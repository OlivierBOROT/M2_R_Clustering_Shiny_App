Projet de création d'une application Shiny R avec un package de clustering fait-maison. 
Contributeurs : 
- Olivier BOROT
- Perrine IBOUROI
- Léo-Paul KNOEPFFLER
