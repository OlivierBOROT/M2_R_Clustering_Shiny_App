## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5,
  warning = FALSE,
  message = FALSE,
  error = FALSE
)
# Suppress FactoMineR messages
suppressPackageStartupMessages({
  library(FactoMineR)
})

## ----load-package-------------------------------------------------------------
library(M2RClust)

# Check if required packages are available
if (!requireNamespace("FactoMineR", quietly = TRUE)) {
  stop("Package 'FactoMineR' is required for this vignette. Please install it with: install.packages('FactoMineR')")
}

## ----data-categorical---------------------------------------------------------
# Create sample categorical data
set.seed(42)
n <- 150

survey_data <- data.frame(
  Age = factor(sample(c("18-25", "26-35", "36-45", "46+"), n, replace = TRUE)),
  Income = factor(sample(c("Low", "Medium", "High"), n, replace = TRUE)),
  Education = factor(sample(c("HS", "Bachelor", "Master", "PhD"), n, replace = TRUE)),
  Region = factor(sample(c("North", "South", "East", "West"), n, replace = TRUE)),
  Preference = factor(sample(c("A", "B", "C"), n, replace = TRUE))
)

cat("Survey data dimensions:", dim(survey_data), "\n")
str(survey_data)

## ----data-mixed---------------------------------------------------------------
# Mixed dataset with automatic discretization
set.seed(123)
n <- 200

mixed_data <- data.frame(
  # Numeric variables (will be discretized)
  Score = rnorm(n, mean = 75, sd = 15),
  Age = runif(n, 18, 65),
  Salary = rlnorm(n, meanlog = 10.5, sdlog = 0.5),
  
  # Categorical variables
  Gender = factor(sample(c("M", "F"), n, replace = TRUE)),
  Department = factor(sample(c("Sales", "IT", "HR", "Marketing"), n, replace = TRUE)),
  Level = factor(sample(c("Junior", "Mid", "Senior"), n, replace = TRUE))
)

cat("Mixed data dimensions:", dim(mixed_data), "\n")
str(mixed_data)

## ----basic-usage--------------------------------------------------------------
# Create the clusterer for categorical data
clusterer <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  linkage = "ward.D2",
  dissimilarity = "dice"
)

# Fit the model
clusterer$fit(survey_data)

# Display results
clusterer$print()

## ----cluster-table------------------------------------------------------------
# Get modality-cluster assignments
cluster_table <- clusterer$get_cluster_table()
print(cluster_table)

## ----summary------------------------------------------------------------------
# Comprehensive summary with inertia decomposition
summary_results <- clusterer$summary()

## ----dice---------------------------------------------------------------------
clusterer_dice <- ModalitiesDiceClusterer$new(
  n_groups = 3,
  dissimilarity = "dice"
)
clusterer_dice$fit(survey_data)

summary_dice <- clusterer_dice$summary()
var_exp_dice <- summary_dice$variance_explained
if (!is.null(var_exp_dice) && is.numeric(var_exp_dice)) {
  cat("Homogeneity (Dice):", round(var_exp_dice, 4), "\n")
} else {
  cat("Homogeneity (Dice): Unable to compute\n")
}

## ----cramer-------------------------------------------------------------------
clusterer_cramer <- ModalitiesDiceClusterer$new(
  n_groups = 3,
  dissimilarity = "cramer"
)
clusterer_cramer$fit(survey_data)

summary_cramer <- clusterer_cramer$summary()
var_exp_cramer <- summary_cramer$variance_explained
if (!is.null(var_exp_cramer) && is.numeric(var_exp_cramer)) {
  cat("Homogeneity (Cramér):", round(var_exp_cramer, 4), "\n")
} else {
  cat("Homogeneity (Cramér): Unable to compute\n")
}

## ----compare-dissim-----------------------------------------------------------
# Extract dissimilarity matrices
dice_mat <- clusterer_dice$get_dice_matrix(as_dist = FALSE)
cramer_mat <- clusterer_cramer$measure_dissimilarity(as_dist = FALSE)

cat("Dice distance range: [", 
    round(min(dice_mat), 3), ", ", 
    round(max(dice_mat), 3), "]\n", sep = "")
cat("Cramér distance range: [", 
    round(min(cramer_mat), 3), ", ", 
    round(max(cramer_mat), 3), "]\n", sep = "")

## ----linkage-ward-------------------------------------------------------------
clust_ward <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  linkage = "ward.D2"
)
clust_ward$fit(survey_data)
summary_ward <- clust_ward$summary()
var_exp_ward <- summary_ward$variance_explained
if (!is.null(var_exp_ward) && is.numeric(var_exp_ward)) {
  cat("Variance explained (Ward):", round(var_exp_ward, 4), "\n")
}

## ----linkage-complete---------------------------------------------------------
clust_complete <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  linkage = "complete"
)
clust_complete$fit(survey_data)
summary_complete <- clust_complete$summary()
var_exp_complete <- summary_complete$variance_explained
if (!is.null(var_exp_complete) && is.numeric(var_exp_complete)) {
  cat("Variance explained (Complete):", round(var_exp_complete, 4), "\n")
}

## ----linkage-average----------------------------------------------------------
clust_average <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  linkage = "average"
)
clust_average$fit(survey_data)
summary_average <- clust_average$summary()
var_exp_average <- summary_average$variance_explained
if (!is.null(var_exp_average) && is.numeric(var_exp_average)) {
  cat("Variance explained (Average):", round(var_exp_average, 4), "\n")
}

## ----auto-discretize----------------------------------------------------------
# Enable automatic discretization (default)
clusterer_auto <- ModalitiesDiceClusterer$new(
  n_groups = 5,
  auto_discretize = TRUE,
  n_bins = 4  # Quartiles
)

clusterer_auto$fit(mixed_data)
clusterer_auto$print()

# Check discretized data
cat("\nOriginal variables:\n")
print(names(mixed_data))

cat("\nModalities after discretization:\n")
print(clusterer_auto$get_modalities())

## ----n-bins-------------------------------------------------------------------
# Fewer bins (terciles)
clust_3bins <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  auto_discretize = TRUE,
  n_bins = 3
)
clust_3bins$fit(mixed_data)

# More bins (quintiles)
clust_5bins <- ModalitiesDiceClusterer$new(
  n_groups = 4,
  auto_discretize = TRUE,
  n_bins = 5
)
clust_5bins$fit(mixed_data)

cat("3 bins - modalities count:", length(clust_3bins$get_modalities()), "\n")
cat("5 bins - modalities count:", length(clust_5bins$get_modalities()), "\n")

## ----plot-dendrogram, fig.cap="Hierarchical clustering dendrogram", fig.height=6----
clusterer$plot_dendrogram()

## ----plot-mca, fig.cap="MCA projection of modalities colored by cluster"------
clusterer$plot_mca(
  color_by_cluster = TRUE,
  add_ellipses = TRUE,
  show_labels = TRUE
)

## ----plot-mca-plain, fig.cap="MCA projection without clustering"--------------
clusterer$plot_mca(
  color_by_cluster = FALSE,
  show_labels = TRUE
)

## ----plot-silhouette, fig.cap="Silhouette scores across different K values"----
clusterer$plot_silhouette(min_k = 2, max_k = 8)

## ----plot-elbow, fig.cap="Elbow method for optimal K"-------------------------
clusterer$plot_elbow(min_k = 2, max_k = 10)

## ----cut-tree-----------------------------------------------------------------
# Original clustering
cat("Original K =", clusterer$n_groups, "\n")
print(table(clusterer$groups))

# Try K = 3
clusterer_k3 <- ModalitiesDiceClusterer$new(n_groups = 3)
clusterer_k3$fit(survey_data)
cat("\nWith K = 3:\n")
print(table(clusterer_k3$groups))

# Try K = 6
clusterer_k6 <- ModalitiesDiceClusterer$new(n_groups = 6)
clusterer_k6$fit(survey_data)
cat("\nWith K = 6:\n")
print(table(clusterer_k6$groups))

# Compare variance explained
summary_k3 <- clusterer_k3$summary()
summary_k4 <- clusterer$summary()
summary_k6 <- clusterer_k6$summary()

if (!is.null(summary_k3$variance_explained) && is.numeric(summary_k3$variance_explained)) {
  cat("\nVariance explained (K=3):", round(summary_k3$variance_explained, 4), "\n")
}
if (!is.null(summary_k4$variance_explained) && is.numeric(summary_k4$variance_explained)) {
  cat("Variance explained (K=4):", round(summary_k4$variance_explained, 4), "\n")
}
if (!is.null(summary_k6$variance_explained) && is.numeric(summary_k6$variance_explained)) {
  cat("Variance explained (K=6):", round(summary_k6$variance_explained, 4), "\n")
}

## ----illustrative-------------------------------------------------------------
# Re-fit clusterer with K=4 for illustrative example
clusterer_illus <- ModalitiesDiceClusterer$new(n_groups = 4)
clusterer_illus$fit(survey_data)

# Create illustrative variable
set.seed(999)
illustrative_var <- factor(
  sample(c("Type1", "Type2", "Type3"), nrow(survey_data), replace = TRUE)
)

# Project onto existing clusters
prediction <- clusterer_illus$predict_illustrative(illustrative_var)

cat("=== Illustrative Variable Projection ===\n\n")

cat("Distances to active modalities:\n")
print(head(prediction$distances))

cat("\nAverage distances by cluster:\n")
print(prediction$by_group)

cat("\nCluster assignments for illustrative modalities:\n")
print(prediction$assignment)

## ----plot-illustrative, fig.cap="MCA with illustrative variable projection"----
clusterer_illus$plot_mca_illustrative(
  illus = illustrative_var,
  show_labels = TRUE
)

## ----export-mca---------------------------------------------------------------
# Create fresh clusterer for export examples
clusterer_export <- ModalitiesDiceClusterer$new(n_groups = 4)
clusterer_export$fit(survey_data)

# Get MCA coordinates for all modalities
mca_coords <- clusterer_export$get_mca_data(n_dims = 2)
head(mca_coords)

# Export to CSV (example)
# write.csv(mca_coords, "mca_coordinates.csv", row.names = FALSE)

## ----export-cluster-----------------------------------------------------------
# Get complete clustering data
cluster_data <- clusterer_export$get_cluster_data(n_dims = 2)
head(cluster_data)

# Analyze cluster composition by variable
table(cluster_data$Variable, cluster_data$Cluster)

## ----cluster-stats------------------------------------------------------------
# Comprehensive statistics per cluster
stats <- clusterer_export$get_cluster_stats(n_dims = 2)
print(stats)

## ----silhouette-data----------------------------------------------------------
# Get silhouette coefficients for all modalities
sil_data <- clusterer_export$get_silhouette_data()
head(sil_data)

# Find poorly clustered modalities
poorly_clustered <- sil_data[sil_data$Silhouette < 0, ]
if (nrow(poorly_clustered) > 0) {
  cat("\nPoorly clustered modalities (negative silhouette):\n")
  print(poorly_clustered)
} else {
  cat("\nNo poorly clustered modalities (all silhouette > 0)\n")
}

# Average silhouette by cluster
aggregate(Silhouette ~ Cluster, data = sil_data, FUN = mean)

## ----matrices-----------------------------------------------------------------
# Get dissimilarity matrix
dissim_matrix <- clusterer_export$measure_dissimilarity(as_dist = FALSE)
cat("Dissimilarity matrix dimensions:", dim(dissim_matrix), "\n")

# Get similarity matrix (normalized to [0,1])
sim_matrix <- clusterer_export$measure_similarity(normalize = TRUE)
cat("Similarity range: [", 
    round(min(sim_matrix), 3), ", ", 
    round(max(sim_matrix), 3), "]\n", sep = "")

# Find most similar modality pairs
sim_matrix_lower <- sim_matrix
sim_matrix_lower[upper.tri(sim_matrix_lower, diag = TRUE)] <- NA
top_pairs <- which(sim_matrix_lower > 0.8, arr.ind = TRUE)
if (nrow(top_pairs) > 0) {
  cat("\nHighly similar modality pairs (similarity > 0.8):\n")
  for (i in 1:min(5, nrow(top_pairs))) {
    row_idx <- top_pairs[i, 1]
    col_idx <- top_pairs[i, 2]
    cat(sprintf("  %s <-> %s: %.3f\n",
                rownames(sim_matrix)[row_idx],
                colnames(sim_matrix)[col_idx],
                sim_matrix[row_idx, col_idx]))
  }
}

## ----inertia------------------------------------------------------------------
summary_res <- clusterer_export$summary()

cat("=== Inertia Analysis ===\n\n")
if (!is.null(summary_res$inertia) && is.numeric(summary_res$inertia)) {
  total_inertia <- summary_res$inertia["total"]
  between_inertia <- summary_res$inertia["between"]
  within_inertia <- summary_res$inertia["within"]
  
  cat(sprintf("Total inertia: %.4f\n", total_inertia))
  if (total_inertia > 0) {
    cat(sprintf("Between-cluster inertia: %.4f (%.1f%%)\n",
                between_inertia, 100 * between_inertia / total_inertia))
    cat(sprintf("Within-cluster inertia: %.4f (%.1f%%)\n",
                within_inertia, 100 * within_inertia / total_inertia))
  }
  if (!is.null(summary_res$variance_explained) && is.numeric(summary_res$variance_explained)) {
    cat(sprintf("R² (variance explained): %.4f\n", summary_res$variance_explained))
  }
}

## ----compare-k----------------------------------------------------------------
# Test different K values
k_values <- 2:8
results <- data.frame(
  K = k_values,
  VarExplained = numeric(length(k_values)),
  AvgSilhouette = numeric(length(k_values))
)

for (i in seq_along(k_values)) {
  k <- k_values[i]
  temp_clusterer <- ModalitiesDiceClusterer$new(n_groups = k)
  temp_clusterer$fit(survey_data)
  
  temp_summary <- temp_clusterer$summary()
  var_exp <- temp_summary$variance_explained
  results$VarExplained[i] <- if (!is.null(var_exp) && is.numeric(var_exp)) var_exp else NA
  
  sil <- temp_clusterer$get_silhouette_data()
  results$AvgSilhouette[i] <- mean(sil$Silhouette, na.rm = TRUE)
}

print(results)

## ----plot-k-selection, fig.width=10, fig.height=4-----------------------------
# Only plot if we have valid data
if (any(!is.na(results$VarExplained)) && any(!is.na(results$AvgSilhouette))) {
  par(mfrow = c(1, 2))
  
  # Variance explained (remove NAs for plotting)
  valid_var <- !is.na(results$VarExplained)
  if (any(valid_var)) {
    plot(results$K[valid_var], results$VarExplained[valid_var], 
         type = "b", pch = 19, col = "steelblue",
         xlab = "Number of Clusters (K)", ylab = "Variance Explained (R²)",
         main = "Variance Explained vs K")
    grid()
  }
  
  # Average silhouette (remove NAs for plotting)
  valid_sil <- !is.na(results$AvgSilhouette)
  if (any(valid_sil)) {
    plot(results$K[valid_sil], results$AvgSilhouette[valid_sil], 
         type = "b", pch = 19, col = "darkgreen",
         xlab = "Number of Clusters (K)", ylab = "Average Silhouette",
         main = "Silhouette Score vs K")
    grid()
  }
  
  par(mfrow = c(1, 1))
} else {
  cat("Unable to generate plots due to missing data\n")
}

## ----real-example-------------------------------------------------------------
# Simulate customer survey data
set.seed(2024)
n_customers <- 300

customer_data <- data.frame(
  AgeGroup = factor(sample(c("18-25", "26-35", "36-50", "51+"), n_customers, 
                           replace = TRUE, prob = c(0.2, 0.35, 0.3, 0.15))),
  Income = factor(sample(c("Low", "Medium", "High", "VeryHigh"), n_customers,
                        replace = TRUE, prob = c(0.25, 0.35, 0.25, 0.15))),
  Education = factor(sample(c("HS", "College", "Bachelor", "Graduate"), n_customers,
                           replace = TRUE, prob = c(0.2, 0.25, 0.35, 0.2))),
  Occupation = factor(sample(c("Student", "Employee", "Manager", "Executive", "Retired"),
                            n_customers, replace = TRUE)),
  ProductInterest = factor(sample(c("Tech", "Fashion", "Home", "Sports", "Books"), 
                                 n_customers, replace = TRUE)),
  PurchaseFreq = factor(sample(c("Rare", "Occasional", "Regular", "Frequent"),
                              n_customers, replace = TRUE,
                              prob = c(0.15, 0.35, 0.35, 0.15)))
)

# Cluster analysis
customer_clusterer <- ModalitiesDiceClusterer$new(
  n_groups = 5,
  linkage = "ward.D2",
  dissimilarity = "dice"
)

customer_clusterer$fit(customer_data)
customer_clusterer$summary()

## ----interpret-segments-------------------------------------------------------
# Get cluster composition
cluster_comp <- customer_clusterer$get_cluster_table()

cat("=== Customer Segment Interpretation ===\n\n")

# Show cluster assignments
for (k in 1:customer_clusterer$n_groups) {
  cat(sprintf("--- Cluster %d ---\n", k))
  cluster_mods <- cluster_comp[cluster_comp$Cluster == k, ]
  
  # Show modalities in this cluster
  cat("Modalities:\n")
  for (i in 1:min(10, nrow(cluster_mods))) {
    cat(sprintf("  - %s (n=%d)\n", 
                cluster_mods$Modality[i], 
                cluster_mods$Frequency[i]))
  }
  cat("\n")
}

## ----plot-customers, fig.width=10, fig.height=8-------------------------------
par(mfrow = c(2, 2))

# Dendrogram
customer_clusterer$plot_dendrogram()

# MCA projection
customer_clusterer$plot_mca(
  color_by_cluster = TRUE,
  add_ellipses = TRUE,
  show_labels = FALSE,
  point_size = 2
)

# Silhouette
customer_clusterer$plot_silhouette(min_k = 2, max_k = 10)

# Elbow
customer_clusterer$plot_elbow(min_k = 2, max_k = 10)

par(mfrow = c(1, 1))

## ----param-table, echo=FALSE--------------------------------------------------
params <- data.frame(
  Parameter = c("n_groups", "linkage", "dissimilarity", "auto_discretize", "n_bins"),
  Type = c("integer", "character", "character", "logical", "integer"),
  Default = c("-", "ward.D2", "dice", "TRUE", "4"),
  Options = c("≥2", "ward.D2, complete, average, single", 
              "dice, cramer", "TRUE/FALSE", "≥2"),
  Description = c(
    "Number of modality clusters",
    "Hierarchical linkage method",
    "Dissimilarity measure",
    "Auto-discretize numeric variables",
    "Number of quantile bins"
  )
)

knitr::kable(params, caption = "ModalitiesDiceClusterer Parameters")

## ----session-info-------------------------------------------------------------
sessionInfo()

